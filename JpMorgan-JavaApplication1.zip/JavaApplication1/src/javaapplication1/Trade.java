/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Juancar
 */
public class Trade {
   public static final String BUY_ORDER = "B";
   public static final String SELL_ORDER = "S";

    
    private String enterprise;
    private String order;
    private Float agreedFd;
    private String currency;
    private Calendar instructionDate;
    private Calendar settlementDate;
    private int units;
    private Float pricePerUnit;

    public Float getAgreedFd() {
        return agreedFd;
    }

    public String getCurrency() {
        return currency;
    }

    public String getEnterprise() {
        return enterprise;
    }

    public Calendar getInstructionDate() {
        return instructionDate;
    }

    public String getOrder() {
        return order;
    }

    public Float getPricePerUnit() {
        return pricePerUnit;
    }

    public Calendar getSettlementDate() {
        return settlementDate;
    }

    public int getUnits() {
        return units;
    }

    public void setAgreedFd(Float agreedFd) {
        this.agreedFd = agreedFd;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setEnterprise(String enterprise) {
        this.enterprise = enterprise;
    }

    public void setInstructionDate(Calendar instructionDate) {
        this.instructionDate = instructionDate;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public void setPricePerUnit(Float pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public void setSettlementDate(Calendar settlementDate) {
        this.settlementDate = settlementDate;
    }

    public void setUnits(int units) {
        this.units = units;
    }

}
