/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameMappingStrategy;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;


/**
 *
 * @author Juancar
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        try {
            //I should use Json
//           List<Trade> list = Main.parseCsvFileToTrades("c:\\orders2JPMorgan.csv", ',');

           List<Trade> list = mockingTrades();

           Main.runningOrders(list);

           int jj=0;
        } catch(Exception e){
            
        }

    }


    public static void runningOrders(List<Trade> trades){
        Map<String, Integer> mapOutgoing= new HashMap<String, Integer>();
        Map<String, Integer> mapIncoming= new HashMap<String, Integer>();
        Map<String, Float> mapIncomingEachDay = new HashMap<String, Float>();
        Map<String, Float> mapOutgoingEachDay = new HashMap<String, Float>();

        if (trades!=null && !trades.isEmpty()){
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
            for(Trade trade : trades){
                Calendar settleDate = Main.obtainApropiateSettleDate(trade);

                Float usd = trade.getPricePerUnit()*trade.getUnits()*trade.getAgreedFd();
                if (Trade.BUY_ORDER.equals(trade.getOrder())){
                    Integer lastValue = mapOutgoing.get(trade.getEnterprise());
                    mapOutgoing.put(trade.getEnterprise(), trade.getUnits()+(lastValue!=null?lastValue:0));
                    Float lastEachdayValue = mapOutgoingEachDay.get(sdf.format(settleDate.getTime()));
                    mapOutgoingEachDay.put(sdf.format(settleDate.getTime()), usd+(lastEachdayValue!=null?lastEachdayValue:0F));
                } else if(Trade.SELL_ORDER.equals(trade.getOrder())){
                    Integer lastBestValue = mapIncoming.get(trade.getEnterprise());
                    mapIncoming.put(trade.getEnterprise(), trade.getUnits()+(lastBestValue!=null?lastBestValue:0));
                    Float lastEachdayValue = mapIncomingEachDay.get(sdf.format(settleDate.getTime()));
                    mapIncomingEachDay.put(sdf.format(settleDate.getTime()), usd+(lastEachdayValue!=null?lastEachdayValue:0F));
                }

            }
            //Printing results
            System.out.println(" ---------   Everyday outgoing ------");
            List<String> outgoingDays = new ArrayList<String>(mapOutgoingEachDay.keySet());
            if (outgoingDays!=null && !outgoingDays.isEmpty()){
                Collections.sort(outgoingDays);
                for (String dateStr : outgoingDays){
                    System.out.println(dateStr+" --> "+mapOutgoingEachDay.get(dateStr));
                }
            }
            System.out.println(" ---------   Everyday incoming ------");
            List<String> incomingDays = new ArrayList<String>(mapIncomingEachDay.keySet());
            if (incomingDays!=null && !incomingDays.isEmpty()){
                Collections.sort(incomingDays);
                for (String dateStr : incomingDays){
                    System.out.println(dateStr+" --> "+mapIncomingEachDay.get(dateStr));
                }
            }

            System.out.println(" ---------  best outgoing company ------");
            if (!mapOutgoing.isEmpty()){
                Map<String, Integer> sortedMap = Main.sortByValue(mapOutgoing);
                List<String> outgoings = new ArrayList<String>(sortedMap.keySet());
                for (String company : outgoings){
                    System.out.println(company+" --> "+sortedMap.get(company));
                }
            }

            System.out.println(" ---------  best incoing company ------");
            if (!mapOutgoing.isEmpty()){
                Map<String, Integer> sortedMap = Main.sortByValue(mapIncoming);
                List<String> incomings = new ArrayList<String>(sortedMap.keySet());
                for (String company : incomings){
                    System.out.println(company+" --> "+sortedMap.get(company));
                }
            }

        }
    }

    /*
     output: 
     *       true  : is sunday-thursday for AED or SAR, and monday-friday other currencies
     *       false : is weekend (friday,saturday for AED or SAR, and saturfay,sunday for other currencies)
     */
    public static Calendar obtainApropiateSettleDate(Trade trade){
        Calendar calendar = trade.getSettlementDate();
        boolean especialCurrency = (Arrays.asList("AED","SAR").contains(trade.getCurrency()));
        int incDays = 0;
        switch (calendar.DAY_OF_WEEK){
            case Calendar.FRIDAY:
                incDays = especialCurrency?2:0;
                break;
            case Calendar.SATURDAY:
                incDays = especialCurrency?1:2;
                break;
            case Calendar.SUNDAY:
                incDays = especialCurrency?0:1;
                break;
        }
        if(incDays>0 ){
            calendar.add(Calendar.DAY_OF_YEAR, incDays);
        }
  
        return calendar;
    }

        private static Map<String, Integer> sortByValue(Map<String, Integer> unsortMap) {

        // 1. Convert Map to List of Map
        List<Map.Entry<String, Integer>> list =
                new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());

        // 2. Sort list with Collections.sort(), provide a custom Comparator
        //    Try switch the o1 o2 position for a different order
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        // 3. Loop the sorted list and put it into a new insertion order Map LinkedHashMap
        Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        /*
        //classic iterator example
        for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext(); ) {
            Map.Entry<String, Integer> entry = it.next();
            sortedMap.put(entry.getKey(), entry.getValue());
        }*/


        return sortedMap;
    }

    public static List<Trade> mockingTrades(){
        List<Trade> trades = new ArrayList<Trade>();
        Trade t1 = new Trade();
        t1.setEnterprise("foo");
        t1.setOrder("B");
        t1.setAgreedFd(new Float(0.50));
        t1.setCurrency("SGP");
        Calendar cal1 = Calendar.getInstance();
        cal1.set(Calendar.YEAR, 2016); cal1.set(Calendar.MONTH, Calendar.JANUARY); cal1.set(Calendar.DAY_OF_MONTH, 0);
        t1.setInstructionDate(cal1);
        Calendar cal2 = Calendar.getInstance();
        cal2.set(Calendar.YEAR, 2016); cal2.set(Calendar.MONTH, Calendar.JANUARY); cal2.set(Calendar.DAY_OF_MONTH, 1);
        t1.setSettlementDate(cal2);
        t1.setUnits(200);
        t1.setPricePerUnit(new Float(100.25));


        Trade t2 = new Trade();
        t2.setEnterprise("var");
        t2.setOrder("S");
        t2.setAgreedFd(new Float(0.22));
        t2.setCurrency("AED");
        Calendar cal3 = Calendar.getInstance();
        cal3.set(Calendar.YEAR, 2016); cal3.set(Calendar.MONTH, Calendar.JANUARY); cal3.set(Calendar.DAY_OF_MONTH, 4);
        t2.setInstructionDate(cal3);
        Calendar cal4 = Calendar.getInstance();
        cal4.set(Calendar.YEAR, 2016); cal4.set(Calendar.MONTH, Calendar.JANUARY); cal4.set(Calendar.DAY_OF_MONTH, 6);
        t2.setSettlementDate(cal4);
        t2.setUnits(450);
        t2.setPricePerUnit(new Float(150.5));


        Trade t3 = new Trade();
        t3.setEnterprise("foo");
        t3.setOrder("B");
        t3.setAgreedFd(new Float(0.50));
        t3.setCurrency("EUR");
        Calendar cal5 = Calendar.getInstance();
        cal5.set(Calendar.YEAR, 2016); cal5.set(Calendar.MONTH, Calendar.JANUARY); cal5.set(Calendar.DAY_OF_MONTH, 1);
        t3.setInstructionDate(cal5);
        Calendar cal6 = Calendar.getInstance();
        cal6.set(Calendar.YEAR, 2016); cal6.set(Calendar.MONTH, Calendar.JANUARY); cal6.set(Calendar.DAY_OF_MONTH, 7);
        t3.setSettlementDate(cal6);
        t3.setUnits(300);
        t3.setPricePerUnit(new Float(98.15));

        Trade t4 = new Trade();
        t4.setEnterprise("san");
        t4.setOrder("B");
        t4.setAgreedFd(new Float(0.70));
        t4.setCurrency("EUR");
        Calendar cal7 = Calendar.getInstance();
        cal7.set(Calendar.YEAR, 2016); cal7.set(Calendar.MONTH, Calendar.JANUARY); cal7.set(Calendar.DAY_OF_MONTH, 1);
        t4.setInstructionDate(cal7);
        Calendar cal8 = Calendar.getInstance();
        cal8.set(Calendar.YEAR, 2016); cal8.set(Calendar.MONTH, Calendar.JANUARY); cal8.set(Calendar.DAY_OF_MONTH, 13);
        t4.setSettlementDate(cal8);
        t4.setUnits(900);
        t4.setPricePerUnit(new Float(63.15));

        Trade t5 = new Trade();
        t5.setEnterprise("bnp");
        t5.setOrder("B");
        t5.setAgreedFd(new Float(0.40));
        t5.setCurrency("EUR");
        Calendar cal9 = Calendar.getInstance();
        cal9.set(Calendar.YEAR, 2016); cal9.set(Calendar.MONTH, Calendar.JANUARY); cal9.set(Calendar.DAY_OF_MONTH, 3);
        t5.setInstructionDate(cal9);
        Calendar cal10 = Calendar.getInstance();
        cal10.set(Calendar.YEAR, 2016); cal10.set(Calendar.MONTH, Calendar.JANUARY); cal10.set(Calendar.DAY_OF_MONTH, 12);
        t5.setSettlementDate(cal10);
        t5.setUnits(750);
        t5.setPricePerUnit(new Float(41.26));

        Trade t6 = new Trade();
        t6.setEnterprise("bnp");
        t6.setOrder("S");
        t6.setAgreedFd(new Float(0.60));
        t6.setCurrency("EUR");
        Calendar cal11 = Calendar.getInstance();
        cal11.set(Calendar.YEAR, 2016); cal11.set(Calendar.MONTH, Calendar.JANUARY); cal11.set(Calendar.DAY_OF_MONTH, 4);
        t6.setInstructionDate(cal11);
        Calendar cal12 = Calendar.getInstance();
        cal12.set(Calendar.YEAR, 2016); cal12.set(Calendar.MONTH, Calendar.JANUARY); cal12.set(Calendar.DAY_OF_MONTH, 17);
        t6.setSettlementDate(cal12);
        t6.setUnits(550);
        t6.setPricePerUnit(new Float(53.14));

        trades.add(t1);
        trades.add(t2);
        trades.add(t3);
        trades.add(t4);
        trades.add(t5);
        trades.add(t6);

        return trades;
    }

    public static List<Trade> parseCsvFileToTrades(final String filename,
                          final char fieldDelimiter) throws FileNotFoundException {
        CSVReader reader = null;
          try {
//            reader = new CSVReader(new BufferedReader(new FileReader(filename)), fieldDelimiter);
              reader = new CSVReader(new FileReader(filename), ',', '\'');
            final HeaderColumnNameMappingStrategy<Trade> strategy =
                                                   new HeaderColumnNameMappingStrategy<Trade>();
            strategy.setType(Trade.class);
            final CsvToBean<Trade> csv = new CsvToBean<Trade>();
            return csv.parse(strategy, reader);
          } finally {
            if (reader != null) {
              try {
                  reader.close();
              } catch (final IOException e) {
                  // ignore
              }
            }
          }
    }

}
